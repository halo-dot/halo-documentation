/*
 * PaymentCardTest.kt
 *
 * Created by Mastercard on 28/5/20 4:18 PM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.model

import com.mastercard.sonic.dxp.sonicdemo.R
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class PaymentCardTest {

    @Test
    fun valid_mastercard() {
        val card = PaymentCard("5555555555554444")

        assertEquals("Valid mastercard card", CardType.MASTERCARD, card.type())
    }

    @Test
    fun invalid_mastercard() {
        val card = PaymentCard("4111111111111111")

        assertNotEquals("Invalid mastercard card", CardType.MASTERCARD, card.type())
    }

    @Test
    fun valid_mastercard_asset() {
        val card = PaymentCard("5555555555554444")

        assertEquals(R.drawable.ic_mastercard, card.cardAsset())
    }

    @Test
    fun invalid_mastercard_asset() {
        val card = PaymentCard("5555555555554444")

        assertNotEquals(R.drawable.ic_visa, card.cardAsset())
    }

    @Test
    fun valid_visa() {
        val card = PaymentCard("4111111111111111")

        assertEquals("Valid visa card", CardType.VISA, card.type())
    }

    @Test
    fun invalid_visa() {
        val card = PaymentCard("378282246310005")

        assertNotEquals("Invalid visa card", CardType.VISA, card.type())
    }

    @Test
    fun valid_visa_asset() {
        val card = PaymentCard("4111111111111111")

        assertEquals(R.drawable.ic_visa, card.cardAsset())
    }

    @Test
    fun invalid_visa_asset() {
        val card = PaymentCard("4111111111111111")

        assertNotEquals(R.drawable.ic_discover, card.cardAsset())
    }

    @Test
    fun valid_amex() {
        val card = PaymentCard("378282246310005")

        assertEquals("Valid amex card", CardType.AMEX, card.type())
    }

    @Test
    fun invalid_amex() {
        val card = PaymentCard("6011000990139424")

        assertNotEquals("Invalid amex card", CardType.AMEX, card.type())
    }

    @Test
    fun valid_amex_asset() {
        val card = PaymentCard("378282246310005")

        assertEquals(R.drawable.ic_american_express, card.cardAsset())
    }

    @Test
    fun invalid_amex_asset() {
        val card = PaymentCard("378282246310005")

        assertNotEquals(R.drawable.ic_discover, card.cardAsset())
    }

    @Test
    fun valid_discover() {
        val card = PaymentCard("6011000990139424")

        assertEquals("Valid discover card", CardType.DISCOVER, card.type())
    }

    @Test
    fun invalid_discover() {
        val card = PaymentCard("378282246310005")

        assertNotEquals("Invalid discover card", CardType.DISCOVER, card.type())
    }

    @Test
    fun valid_discover_asset() {
        val card = PaymentCard("6011000990139424")

        assertEquals(R.drawable.ic_discover, card.cardAsset())
    }

    @Test
    fun invalid_discover_asset() {
        val card = PaymentCard("6011000990139424")

        assertNotEquals(R.drawable.ic_mastercard, card.cardAsset())
    }

    @Test
    fun valid_masking() {
        val card = PaymentCard("6011000990139424")

        assertEquals("•••• 9424", card.maskedCardNumber())
    }

    @Test
    fun invalid_masking() {
        val card = PaymentCard("6011000990139424")

        assertNotEquals("••••• 9424", card.maskedCardNumber())
    }
}