/*
 * ConfirmOrderFragment.kt
 *
 * Created by Mastercard on 28/5/20 11:00 AM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.ui.confirmorder

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.addCallback
import androidx.constraintlayout.widget.Group
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.mastercard.dxp.uicomponent.button.DxpButton
import com.mastercard.dxp.uicomponent.textinputlayout.DxpAutoCompleteTextView
import com.mastercard.sonic.controller.SonicController
import com.mastercard.sonic.controller.SonicEnvironment
import com.mastercard.sonic.controller.SonicType
import com.mastercard.sonic.dxp.sonicdemo.R
import com.mastercard.sonic.dxp.sonicdemo.model.CardType
import com.mastercard.sonic.dxp.sonicdemo.model.PaymentCard
import com.mastercard.sonic.dxp.sonicdemo.model.cardAsset
import com.mastercard.sonic.dxp.sonicdemo.model.maskedCardNumber
import com.mastercard.sonic.dxp.sonicdemo.model.type
import com.mastercard.sonic.listeners.OnCompleteListener
import com.mastercard.sonic.listeners.OnPrepareListener
import com.mastercard.sonic.model.SonicMerchant
import com.mastercard.sonic.widget.SonicBackground
import com.mastercard.sonic.widget.SonicView


class ConfirmOrderFragment : Fragment(R.layout.fragment_confirm_order) {

    private val TAG: String = "ConfirmOrderFragment"

    private var dialogShown: Boolean = false
    private var isSonicAnimationCompleted = false
    private var selectedPaymentCardPosition: Int = 0

    private lateinit var edtPayCards: DxpAutoCompleteTextView
    private lateinit var sonicView: SonicView
    private lateinit var btnConfirmOrder: DxpButton
    private lateinit var orderGroup: Group
    private lateinit var sonicMerchant: SonicMerchant

    private val sonicController = SonicController()

    companion object {
        private const val KEY_ANIMATION_COMPLETED = "sonic"
        private const val KEY_DIALOG = "dialog"
        private const val KEY_PAYMENT_CARD_SELECTION = "payment_card_selection"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            //No OPS
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        sonicView = view.findViewById(R.id.sonic_view)
        btnConfirmOrder = view.findViewById(R.id.btn_confirm_order)
        orderGroup = view.findViewById(R.id.group)
        edtPayCards = view.findViewById(R.id.edt_payment_cards)

        // Ex:- To change the background to white
        // sonicView.background = SonicBackground.WHITE

        btnConfirmOrder.setOnClickListener {
            dialogShown = true
            findNavController().navigate(R.id.progressDialogFragment)
        }

        edtPayCards.setOnItemClickListener { _, _, position, _ ->
            setSelectedPaymentCard(position)
        }

        findNavController().addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.confirmOrderFragment -> {
                    paymentSuccess()
                }
            }
        }

        prepareSonicAnimation()
    }

    override fun onResume() {
        super.onResume()

        edtPayCards.setAdapter(
            PaymentCardAdapter(
                requireContext(),
                R.layout.payment_card_item
            )
        )

        setSelectedPaymentCard()

        if (isSonicAnimationCompleted) {
            findNavController().navigate(R.id.action_confirmOrderFragment_to_thankYouFragment)
        }

    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        if (savedInstanceState != null) {
            dialogShown = savedInstanceState.getBoolean(KEY_DIALOG)
            isSonicAnimationCompleted = savedInstanceState.getBoolean(KEY_ANIMATION_COMPLETED)
            selectedPaymentCardPosition = savedInstanceState.getInt(KEY_PAYMENT_CARD_SELECTION)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_DIALOG, dialogShown)
        outState.putInt(KEY_PAYMENT_CARD_SELECTION, selectedPaymentCardPosition)
        outState.putBoolean(KEY_ANIMATION_COMPLETED, isSonicAnimationCompleted)
    }

    private fun prepareSonicAnimation() {

        sonicMerchant = SonicMerchant.Builder()
            .merchantName("Uber")
            .city("New York")
            .merchantCategoryCodes(arrayOf("MCC 5122"))
            .countryCode("USA")
            .merchantId("UberId")
            .build()

        /*
         * SonicEnvironment.SANDBOX: Please pass SANDBOX in prepare() while the application is in developing or testing.
         * SonicEnvironment.PRODUCTION: Please pass PRODUCTION when the application getting release to live users.
         */

        sonicController.prepare(sonicType = SonicType.SOUND_AND_ANIMATION,
            sonicCue = "checkout",
            sonicEnvironment = SonicEnvironment.SANDBOX,
            merchant = sonicMerchant,
            isHapticsEnabled = true,
            context = requireContext(),
            onPrepareListener = object : OnPrepareListener {
                override fun onPrepared(statusCode: Int) {
                    btnConfirmOrder.isEnabled = true
                    Log.d(TAG, "onPrepared() statusCode = $statusCode")
                }
            })
    }

    private fun setSelectedPaymentCard(position: Int = selectedPaymentCardPosition) {
        selectedPaymentCardPosition = position
        val card = edtPayCards.adapter.getItem(position) as PaymentCard
        edtPayCards.setText(card.maskedCardNumber(), false)
        edtPayCards.setCompoundDrawablesRelativeWithIntrinsicBounds(card.cardAsset(), 0, 0, 0)
    }

    private fun getSelectedPaymentCard(position: Int = selectedPaymentCardPosition): PaymentCard {
        return edtPayCards.adapter.getItem(position) as PaymentCard
    }

    private fun paymentSuccess() {
        if (dialogShown) {
            dialogShown = false
            orderGroup.visibility = View.GONE
            sonicView.visibility = View.VISIBLE

            if (getSelectedPaymentCard().type() != CardType.MASTERCARD) {
                findNavController().navigate(R.id.action_confirmOrderFragment_to_thankYouFragment)
            } else {
                sonicController.play(sonicView, object : OnCompleteListener {
                    override fun onComplete(statusCode: Int) {
                        Log.d(TAG, "onComplete() statusCode = $statusCode")
                        isSonicAnimationCompleted = true
                        findNavController().navigate(R.id.action_confirmOrderFragment_to_thankYouFragment)
                    }
                })
            }

        }
    }
}
