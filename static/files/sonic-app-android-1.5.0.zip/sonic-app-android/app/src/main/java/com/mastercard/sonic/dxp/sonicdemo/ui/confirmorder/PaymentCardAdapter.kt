/*
 * PaymentCardAdapter.kt
 *
 * Created by Mastercard on 28/5/20 11:01 AM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.ui.confirmorder

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import com.mastercard.dxp.uicomponent.textview.DxpTextView
import com.mastercard.sonic.dxp.sonicdemo.R
import com.mastercard.sonic.dxp.sonicdemo.model.PaymentCard
import com.mastercard.sonic.dxp.sonicdemo.model.cardAsset
import com.mastercard.sonic.dxp.sonicdemo.model.maskedCardNumber

class PaymentCardAdapter(
    context: Context,
    private val layout: Int
) : ArrayAdapter<PaymentCard>(context, layout) {

    private val paymentCards = prepareCards()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view: View
        val viewHolder: ViewHolder

        val inflater = LayoutInflater.from(parent.context)
        if (convertView == null) {
            view = inflater.inflate(layout, null)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder

        } else {

            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        val paymentCard = paymentCards[position]
        viewHolder.txtCardName.text = paymentCard.maskedCardNumber()
        viewHolder.txtCardName.setCompoundDrawablesWithIntrinsicBounds(
            paymentCard.cardAsset(),
            0,
            0,
            0
        )
        return view
    }

    override fun getItem(position: Int): PaymentCard {
        return paymentCards[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return paymentCards.size
    }

    inner class ViewHolder(view: View) {
        val txtCardName: DxpTextView = view.findViewById(R.id.txt_card_number)
    }

    private fun prepareCards() = listOf(
        PaymentCard("5555555555554444"),
        PaymentCard("4012888888881881"),
        PaymentCard("378282246310005"),
        PaymentCard("6011111111111117")
    )
}