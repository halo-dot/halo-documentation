/*
 * StartDemoFragment.kt
 *
 * Created by Mastercard on 14/4/20 4:52 PM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.ui.startdemo

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.mastercard.dxp.uicomponent.button.DxpButton
import com.mastercard.sonic.dxp.sonicdemo.R


class StartDemoFragment : Fragment(R.layout.fragment_start_demo) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnStartDemo: DxpButton = view.findViewById(R.id.btn_start_demo)

        btnStartDemo.setOnClickListener {
            findNavController().navigate(R.id.action_startDemoFragment_to_confirmOrderFragment)
        }
    }
}
