/*
 * CardType.kt
 *
 * Created by Mastercard on 28/5/20 12:54 PM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.model

enum class CardType {
    MASTERCARD,
    VISA,
    DISCOVER,
    AMEX,
    INVALID
}