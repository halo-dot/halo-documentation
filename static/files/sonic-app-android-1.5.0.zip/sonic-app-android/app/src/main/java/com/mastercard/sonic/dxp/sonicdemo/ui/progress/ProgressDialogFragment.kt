/*
 * ProgressDialogFragment.kt
 *
 * Created by Mastercard on 28/5/20 11:01 AM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.ui.progress

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.fragment.app.DialogFragment
import androidx.navigation.fragment.findNavController
import com.mastercard.dxp.uicomponent.textview.DxpTextView
import com.mastercard.sonic.dxp.sonicdemo.R

class ProgressDialogFragment : DialogFragment() {

    private val startTimeInMillis: Long = 5000
    private val countDownInterval: Long = 2500
    private var timeLeftInMillis: Long = startTimeInMillis
    private var endTimeInMillis: Long = 0
    private var isTimerRunning: Boolean = false
    private lateinit var paymentTimer: PaymentTimer
    private lateinit var txtProgressBar: DxpTextView

    companion object{
        private const val KEY_MILLI_LEFT = "milliLeft"
        private const val KEY_END_MILLI = "endMilli"
        private const val KEY_IS_TIMER_RUNNING = "isTimerRunning"
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return super.onCreateDialog(savedInstanceState).apply {
            window?.requestFeature(Window.FEATURE_NO_TITLE)
            window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            isCancelable = false
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_progress_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        txtProgressBar = view.findViewById(R.id.txt_progress_text)

    }

    override fun onResume() {
        super.onResume()
        startTimer()
    }

    private fun pauseTimer() {
        paymentTimer.cancel()
        isTimerRunning = false
    }

    private fun startTimer() {
        endTimeInMillis = System.currentTimeMillis() + timeLeftInMillis
        paymentTimer = PaymentTimer(timeLeftInMillis, countDownInterval)
        paymentTimer.start()
        isTimerRunning = true
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(KEY_MILLI_LEFT, timeLeftInMillis)
        outState.putLong(KEY_END_MILLI, endTimeInMillis)
        outState.putBoolean(KEY_IS_TIMER_RUNNING, isTimerRunning)

        pauseTimer()
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)

        savedInstanceState?.let {
            timeLeftInMillis = it.getLong(KEY_MILLI_LEFT)
            endTimeInMillis = it.getLong(KEY_END_MILLI)
            isTimerRunning = it.getBoolean(KEY_IS_TIMER_RUNNING)

            if (isTimerRunning) {
                endTimeInMillis = System.currentTimeMillis() - timeLeftInMillis
            }
        }
    }

    inner class PaymentTimer(
        millisInFuture: Long,
        countDownInterval: Long
    ) : CountDownTimer(millisInFuture, countDownInterval) {

        override fun onFinish() {
            isTimerRunning = false
            findNavController().popBackStack()
        }

        override fun onTick(millisUntilFinished: Long) {
            timeLeftInMillis = millisUntilFinished
            if (millisUntilFinished < countDownInterval && isAdded) {
                txtProgressBar.text = getString(R.string.progress_msg_2)
            }
        }
    }
}