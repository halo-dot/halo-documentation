/*
 * ThankYouFragment.kt
 *
 * Created by Mastercard on 17/4/20 10:13 AM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.ui.thankyou

import android.os.Bundle
import android.text.Html
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.mastercard.dxp.uicomponent.button.DxpButton
import com.mastercard.dxp.uicomponent.textview.DxpTextView
import com.mastercard.sonic.dxp.sonicdemo.R


class ThankYouFragment : Fragment(R.layout.fragment_thank_you) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val txtOrderReceived: DxpTextView = view.findViewById(R.id.txt_order_received)

        txtOrderReceived.text = Html.fromHtml(getString(R.string.we_received_order))

        val btnStartOver: DxpButton = view.findViewById(R.id.btn_start_over)

        btnStartOver.setOnClickListener {
            findNavController().navigate(R.id.action_nav_graph_self)
        }
    }
}
