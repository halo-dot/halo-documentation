/*
 * MainActivity.kt
 *
 * Created by Mastercard on 14/4/20 4:12 PM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.appbar.MaterialToolbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolBar: MaterialToolbar = findViewById(R.id.toolbar)

        val navController = findNavController(R.id.navigation_host_fragment)

        val appBarConfiguration =
            AppBarConfiguration(setOf(R.id.startDemoFragment, R.id.confirmOrderFragment))

        toolBar.setupWithNavController(navController, appBarConfiguration)

        navController.addOnDestinationChangedListener { _, destination, _ ->
            toolBar.visibility = handleToolBarVisibility(destination.id)
        }
    }

    private fun handleToolBarVisibility(destination: Int): Int = when (destination) {

        R.id.startDemoFragment -> {
            View.GONE
        }
        else -> {
            View.VISIBLE
        }
    }
}
