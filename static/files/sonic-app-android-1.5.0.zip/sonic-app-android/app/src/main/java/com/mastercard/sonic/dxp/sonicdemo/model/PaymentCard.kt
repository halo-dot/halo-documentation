/*
 * PaymentCard.kt
 *
 * Created by Mastercard on 28/5/20 12:54 PM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo.model

import com.mastercard.sonic.dxp.sonicdemo.R
import java.util.regex.Pattern

fun PaymentCard.type(): CardType {

    val regMastercard = "^5[1-5][0-9]{14}$".toRegex()
    val regVisa = "^4[0-9]{12}(?:[0-9]{3})?\$".toRegex()
    val regDiscover = "^6(?:011|5[0-9]{2})[0-9]{12}\$".toRegex()
    val regAmex = "^3[47][0-9]{13}\$".toRegex()

    when {
        regMastercard.matches(this.cardNumber) -> {
            return CardType.MASTERCARD
        }
        regVisa.matches(this.cardNumber) -> {
            return CardType.VISA
        }
        regDiscover.matches(this.cardNumber) -> {
            return CardType.DISCOVER
        }
        regAmex.matches(this.cardNumber) -> {
            return CardType.AMEX
        }
        else -> {
            return CardType.INVALID
        }
    }
}


fun PaymentCard.cardAsset(): Int = when (this.type()) {

    CardType.MASTERCARD -> {
        R.drawable.ic_mastercard
    }

    CardType.VISA -> {
        R.drawable.ic_visa
    }

    CardType.DISCOVER -> {
        R.drawable.ic_discover
    }

    CardType.AMEX -> {
        R.drawable.ic_american_express
    }

    CardType.INVALID -> {
        throw IllegalStateException("Invalid card selected")
    }
}

fun PaymentCard.maskedCardNumber(): String {
    val pattern = Pattern.compile("\\b([0-9]{4})[0-9]{0,9}([0-9]{4})\\b")
    val matcher = pattern.matcher(this.cardNumber)
    return matcher.replaceAll("•••• $2")
}

data class PaymentCard(
    val cardNumber: String
)
