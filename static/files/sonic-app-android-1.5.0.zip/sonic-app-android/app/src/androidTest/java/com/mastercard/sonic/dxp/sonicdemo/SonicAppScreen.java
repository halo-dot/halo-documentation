/*
 * SonicAppScreen.java
 *
 * Created by Mastercard on 1/6/20 11:13 AM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo;

import android.content.res.Resources;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.ViewInteraction;
import androidx.test.espresso.matcher.RootMatchers;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.isFocusable;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.not;

public class SonicAppScreen {

    private static final Resources resources = ApplicationProvider.getApplicationContext().getResources();

    public static void checkBrandingLogo() {
        ViewInteraction imageView = onView(
                allOf(withId(R.id.img_mc_logo)));
        imageView.check(matches(isDisplayed()));
    }

    public static void checkFooterLinks() {
        onView(allOf(withId(R.id.txt_terms_of_use))).check(matches(withText(resources.getString(R.string.terms_of_use))));
        onView(allOf(withId(R.id.txt_privacy_policy))).check(matches(withText(resources.getString(R.string.privacy_policy))));
        onView(allOf(withId(R.id.txt_copy_right))).check(matches(withText(resources.getString(R.string.copy_right))));

    }

    public static void checkDevelopedBy() {
        String developBy = resources.getString(R.string.developed_by_dxp);
        onView(allOf(withText(developBy))).check(matches(isEnabled()));
        onView(allOf(withText(developBy))).check(matches(not(isClickable())));
        onView(allOf(withText(developBy))).check(matches(not(isFocusable())));
    }

    public static void replayDemo() {
        onView(allOf(withId(R.id.btn_start_over))).perform(click());
    }


    public static void checkThanksMessage() throws InterruptedException {
        Thread.sleep(10);
        onView(allOf(withId(R.id.txt_thank_you))).check(matches(isEnabled()));
    }

    public static void checkBrandingTitle() {
        String title = resources.getString(R.string.sonic_demo_title);
        ViewInteraction textView = onView(
                allOf(withId(R.id.tv_dxp_title), withText(title),
                        childAtPosition(
                                childAtPosition(
                                        withId(R.id.navigation_host_fragment),
                                        0),
                                2),
                        isDisplayed()));
        textView.check(matches(withText(title)));
    }

    public static void selectPaymentCardVISA() {
        onView(allOf(withId(R.id.edt_payment_cards))).perform(click());
        onView(withText("•••• 1881"))
                .inRoot(RootMatchers.isPlatformPopup())
                .perform(click());
    }

    public static void selectPaymentCardMASTERCARD() throws InterruptedException {
        onView(allOf(withId(R.id.edt_payment_cards))).perform(click());
        Thread.sleep(10);
        onView(withText("•••• 4444"))
                .inRoot(RootMatchers.isPlatformPopup())
                .perform(click());

    }

    public static void selectPaymentCardAmerican() {
        onView(allOf(withId(R.id.edt_payment_cards))).perform(click());
        onView(withText("•••• 0005"))
                .inRoot(RootMatchers.isPlatformPopup())
                .perform(click());
    }

    public static void selectPaymentCardDiscover() {
        onView(allOf(withId(R.id.edt_payment_cards))).perform(click());
        onView(withText("•••• 1117"))
                .inRoot(RootMatchers.isPlatformPopup())
                .perform(click());
    }

    public static void checkSonicEnable() throws InterruptedException {
        Thread.sleep(5000);
        onView(allOf(withId(R.id.sonic_view))).check(matches(isEnabled()));
    }

    public static void confirmOrder() {
        onView(allOf(withId(R.id.btn_confirm_order))).perform(click());
    }

    public static void checkWelcomeMessage() {
        ViewInteraction textView2 = onView(
                allOf(withId(R.id.tv_dxp_welcome_msg)));
        textView2.check(matches(withText(resources.getString(R.string.sonic_demo_welcome_message))));
    }

    public static void startDemo() {
        ViewInteraction btn_start_demo = onView(
                allOf(withId(R.id.btn_start_demo),
                        childAtPosition(
                                childAtPosition(
                                        withId(R.id.navigation_host_fragment),
                                        0),
                                4),
                        isDisplayed()));
        btn_start_demo.check(matches(isDisplayed()));
        btn_start_demo.perform(click());
    }

    public static void checkTitle() {
        onView(allOf(withText(resources.getString(R.string.kicks)))).check(matches(isEnabled()));
    }

    public static void checkImageProcessCompleted() {
        onView(allOf(withId(R.id.img_process_completed))).check(matches(isEnabled()));
    }

    public static void checkTextOrderReceived() {
        onView(allOf(withId(R.id.txt_order_received))).check(matches(withText(Html.fromHtml(resources.getString(R.string.we_received_order)).toString())));
    }

    public static void checkProductAndCustomerDetail() {
        ViewInteraction txt_item = onView(
                allOf(withId(R.id.txt_item)));
        txt_item.check(matches(withText(resources.getString(R.string.item))));

        ViewInteraction img_item = onView(
                allOf(withId(R.id.img_item)));
        img_item.check(matches(isDisplayed()));

        ViewInteraction txt_item_name = onView(
                allOf(withId(R.id.txt_item_name)));
        txt_item_name.check(matches(withText(resources.getString(R.string.white_sneakers))));

        ViewInteraction txt_item_quantity = onView(
                allOf(withId(R.id.txt_item_quantity)));
        txt_item_quantity.check(matches(withText(resources.getString(R.string.qty))));

        ViewInteraction txt_item_size = onView(
                allOf(withId(R.id.txt_item_size)));
        txt_item_size.check(matches(withText(resources.getString(R.string.size))));

        ViewInteraction txt_item_color = onView(
                allOf(withId(R.id.txt_item_color)));
        txt_item_color.check(matches(withText(resources.getString(R.string.color))));

        ViewInteraction txt_ship = onView(
                allOf(withId(R.id.txt_ship)));
        txt_ship.check(matches(withText(resources.getString(R.string.ship_to))));

        ViewInteraction textView11 = onView(
                allOf(withId(R.id.txt_person_name)));
        textView11.check(matches(withText(resources.getString(R.string.person_name))));

        ViewInteraction txt_address = onView(
                allOf(withId(R.id.txt_address)));
        txt_address.check(matches(withText(resources.getString(R.string.address))));

        ViewInteraction textView13 = onView(
                allOf(withId(R.id.txt_pay_with)));
        textView13.check(matches(withText(resources.getString(R.string.pay_with))));

        ViewInteraction edt_payment_cards = onView(
                allOf(withId(R.id.edt_payment_cards)));
        edt_payment_cards.check(matches(withText("•••• 4444")));

        ViewInteraction txt_sub_total = onView(
                allOf(withId(R.id.txt_sub_total)));
        txt_sub_total.check(matches(withText(resources.getString(R.string.sub_total))));

        ViewInteraction txt_sub_total_amount = onView(
                allOf(withId(R.id.txt_sub_total_amount)));
        txt_sub_total_amount.check(matches(withText(resources.getString(R.string.sub_total_amount))));

        ViewInteraction txt_total = onView(
                allOf(withId(R.id.txt_total)));
        txt_total.check(matches(withText(resources.getString(R.string.total))));

        ViewInteraction txt_total_amount = onView(
                allOf(withId(R.id.txt_total_amount)));
        txt_total_amount.check(matches(withText(resources.getString(R.string.sub_total_amount))));

        ViewInteraction btn_confirm_order = onView(
                allOf(withId(R.id.btn_confirm_order)));

        btn_confirm_order.check(matches(withText(resources.getString(R.string.confirm_oder))));
    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
