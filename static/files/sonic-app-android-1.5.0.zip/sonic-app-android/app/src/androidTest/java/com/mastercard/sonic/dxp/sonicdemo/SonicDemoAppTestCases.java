/*
 * SonicDemoAppTestCases.java
 *
 * Created by Mastercard on 1/6/20 11:15 AM
 * Copyright (c) 2020 Mastercard. All rights reserved
 */

package com.mastercard.sonic.dxp.sonicdemo;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.LargeTest;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class SonicDemoAppTestCases {

    @Rule
    public ActivityScenarioRule<MainActivity> mActivityTestRule = new ActivityScenarioRule<>(MainActivity.class);

    @Test
    public void checkAppWorkFlowAndStaticContent() throws InterruptedException {

        SonicAppScreen.checkDevelopedBy();
        SonicAppScreen.checkBrandingLogo();
        SonicAppScreen.checkBrandingTitle();
        SonicAppScreen.checkWelcomeMessage();
        SonicAppScreen.startDemo();
        SonicAppScreen.checkProductAndCustomerDetail();
        SonicAppScreen.selectPaymentCardMASTERCARD();
        SonicAppScreen.confirmOrder();
        Thread.sleep(10000);
        SonicAppScreen.checkThanksMessage();
        SonicAppScreen.checkTitle();
        SonicAppScreen.checkImageProcessCompleted();
        SonicAppScreen.checkTextOrderReceived();
        SonicAppScreen.checkFooterLinks();
        SonicAppScreen.replayDemo();
    }

    @Test
    public void checkWithVISACard() throws InterruptedException {
        SonicAppScreen.startDemo();
        SonicAppScreen.selectPaymentCardVISA();
        SonicAppScreen.confirmOrder();
        Thread.sleep(5000);
        SonicAppScreen.checkThanksMessage();
        SonicAppScreen.checkImageProcessCompleted();
    }

    @Test
    public void checkWithDiscoverCard() throws InterruptedException {
        SonicAppScreen.startDemo();
        SonicAppScreen.selectPaymentCardDiscover();
        SonicAppScreen.confirmOrder();
        Thread.sleep(5000);
        SonicAppScreen.checkThanksMessage();
        SonicAppScreen.checkImageProcessCompleted();
    }

    @Test
    public void checkWithAmericanCard() throws InterruptedException {
        SonicAppScreen.startDemo();
        SonicAppScreen.selectPaymentCardAmerican();
        SonicAppScreen.confirmOrder();
        Thread.sleep(5000);
        SonicAppScreen.checkThanksMessage();
        SonicAppScreen.checkImageProcessCompleted();
    }

    @Test
    public void CheckSonicEnableWithMastercard() throws InterruptedException {
        SonicAppScreen.startDemo();
        SonicAppScreen.selectPaymentCardMASTERCARD();
        SonicAppScreen.confirmOrder();
        SonicAppScreen.checkSonicEnable();
        Thread.sleep(5000);
        SonicAppScreen.checkThanksMessage();
        SonicAppScreen.checkImageProcessCompleted();
    }
}
