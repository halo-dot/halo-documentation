package com.visa.vsb.containers

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.PopupWindow
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.visa.CheckmarkMode
import com.visa.CheckmarkTextOption
import com.visa.SensoryBrandingView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.main_activity)

        // Regular Alert Dialog
        val animateInRegularDialogButton = findViewById<Button>(
            R.id.animate_in_regular_dialog_button
        )
        val vsbForRegularDialog = createVSB()
        val regularDialog = AlertDialog.Builder(this)
            .setView(vsbForRegularDialog)
            .create()
        animateInRegularDialogButton.setOnClickListener {
            regularDialog.show()
            vsbForRegularDialog.animate { result ->
                Log.d("SensoryBrandingView", result?.message ?: "OK")
                if (regularDialog.isShowing) {
                    regularDialog.dismiss()
                }
            }
        }


        // Custom Dialog
        val animateInCustomDialogButton = findViewById<Button>(
            R.id.animate_in_custom_dialog_button
        )
        animateInCustomDialogButton.setOnClickListener {
            val customDialog = MyDialog(this)
            customDialog.show()
        }


        // Dialog Fragment
        val animateInFragmentDialogButton = findViewById<Button>(
            R.id.animate_in_fragment_dialog_button
        )
        animateInFragmentDialogButton.setOnClickListener {
            MyDialogFragment().show(supportFragmentManager, "fragmentDialog")
        }


        // Popup Window
        val animateInPopupWindowButton = findViewById<Button>(
            R.id.animate_in_popup_window_button
        )
        animateInPopupWindowButton.setOnClickListener {
            val view = LayoutInflater.from(this).inflate(R.layout.dialog_layout, null)
            val vsb = view.findViewById<SensoryBrandingView>(R.id.vsb)
            val pop = PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
            pop.showAsDropDown(animateInPopupWindowButton)
            vsb.animate {
                pop.dismiss()
            }
        }

    }

    private fun createVSB(): SensoryBrandingView {
        val vsb = SensoryBrandingView(this, null)
        vsb.apply {
            backdropColor = Color.parseColor("#123333")
            languageCode = "en"
            hapticEnabled = true
            soundEnabled = true
            checkmarkMode = CheckmarkMode.CHECKMARK_WITH_TEXT
            checkmarkText = CheckmarkTextOption.APPROVE
        }
        return vsb
    }

}