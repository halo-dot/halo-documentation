package com.visa.vsb.containers

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AppCompatDialog
import com.visa.CheckmarkMode
import com.visa.CheckmarkTextOption
import com.visa.SensoryBrandingView

// To test the scenario that Activity context is wrapped as ContextThemeWrapper.
class MyDialog(activity: ComponentActivity) : AppCompatDialog(
    activity
) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_layout)

        val vsb = findViewById<View>(R.id.vsb) as SensoryBrandingView?
        vsb!!.backdropColor = Color.WHITE
        vsb.languageCode = "en"
        vsb.hapticEnabled = true
        vsb.soundEnabled = true
        vsb.checkmarkMode = CheckmarkMode.NONE
        vsb.checkmarkText = CheckmarkTextOption.APPROVE

        vsb.animate { error: Error? ->
            Log.d("SensoryBrandingView", (if (error == null) "OK" else error.message)!!)
            dismiss()
        }
    }
}