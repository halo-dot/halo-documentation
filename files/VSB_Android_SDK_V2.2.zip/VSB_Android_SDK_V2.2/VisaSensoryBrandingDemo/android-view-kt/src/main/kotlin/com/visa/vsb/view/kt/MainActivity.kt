package com.visa.vsb.view.kt

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.Button
import com.visa.CheckmarkMode
import com.visa.CheckmarkTextOption
import com.visa.SensoryBrandingView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Step1: Set up contents from the layout(xml) file,
        // and get the SensoryBrandingView instance by view id.
        setContentView(R.layout.main_activity)
        val vsb = findViewById<SensoryBrandingView>(R.id.vsb)
        val animateButton = findViewById<Button>(R.id.animate_button)

        // Step2: Configure the SensoryBrandingView.
        vsb.apply {
            backdropColor = Color.parseColor("#123333")
            languageCode = "en"
            hapticEnabled = true
            soundEnabled = true
            checkmarkMode = CheckmarkMode.CHECKMARK_WITH_TEXT
            checkmarkText = CheckmarkTextOption.APPROVE
        }

        // Step3: Trigger the animation by `SensoryBrandingView#animate(completion: (result: Error?) -> Unit)`.
        animateButton.setOnClickListener {
            vsb.animate { result ->
                Log.d("SensoryBrandingView", result?.message ?: "OK")
            }
        }
    }
}