package com.visa.vsb.view.jv;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;

import com.visa.CheckmarkMode;
import com.visa.CheckmarkTextOption;
import com.visa.SensoryBrandingView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        // Step1: Set up contents from the layout(xml) file,
        // and get the SensoryBrandingView instance by view id.
        SensoryBrandingView vsb = (SensoryBrandingView) findViewById(R.id.vsb);

        // Step2: Configure the SensoryBrandingView.
        vsb.setBackdropColor(Color.parseColor("#123333"));
        vsb.setLanguageCode("en");
        vsb.setHapticEnabled(true);
        vsb.setSoundEnabled(true);
        vsb.setCheckmarkMode(CheckmarkMode.CHECKMARK_WITH_TEXT);
        vsb.setCheckmarkText(CheckmarkTextOption.APPROVE);

        // Step3: Trigger the animation by `SensoryBrandingView#animate(completion: (result: Error?) -> Unit)`.
        vsb.animate(error -> {
            Log.d("SensoryBrandingView", error == null ? "OK" : error.getMessage());
            return null;
        });
    }

}
