plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.visa.vsb.view.jv"
    defaultConfig {
        minSdk = 21 // Should confirmed with Security team every year
        targetSdk = 34 // Update this every year to catch up new Android APIs
        compileSdk = 34 // Update this every year to catch up new Android APIs
        versionCode = 9
        versionName = "2.2"
    }
    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    sourceSets["main"].java.srcDir("src/main/kotlin")

    kotlinOptions {
        jvmTarget = "11"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    usingVisaSensoryBrandingSourceOrApply {
        implementation(project(":visa-sensory-branding-sdk"))
    }
    implementation("androidx.appcompat:appcompat:1.6.1")
}
