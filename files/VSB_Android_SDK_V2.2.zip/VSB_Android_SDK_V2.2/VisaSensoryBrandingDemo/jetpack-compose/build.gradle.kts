plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.visa.vsb.compose"
    defaultConfig {
        minSdk = 21 // Should confirmed with Security team every year
        targetSdk = 34 // Update this every year to catch up new Android APIs
        compileSdk = 34 // Update this every year to catch up new Android APIs
        versionCode = 9
        versionName = "2.2"
    }
    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    sourceSets["main"].java.srcDir("src/main/kotlin")

    kotlinOptions {
        jvmTarget = "11"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.4.8"
    }

}

dependencies {
    val composeVer = "1.4.3"
    implementation("androidx.compose.material3:material3:1.1.1")
    implementation("androidx.compose.ui:ui:$composeVer")
    implementation("androidx.core:core-ktx:1.10.1")
    implementation ("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    implementation("androidx.activity:activity-compose:1.7.2")
    implementation("androidx.compose.ui:ui-tooling-preview:$composeVer")
    implementation("com.google.accompanist:accompanist-systemuicontroller:0.25.1")
    implementation("androidx.constraintlayout:constraintlayout-compose:1.0.1")
    implementation("androidx.navigation:navigation-compose:2.6.0")
    debugImplementation("androidx.compose.ui:ui-tooling:$composeVer")

    implementation("androidx.appcompat:appcompat:1.6.1")

    usingVisaSensoryBrandingSourceOrApply {
        implementation(project(":visa-sensory-branding-sdk"))
    }
}
