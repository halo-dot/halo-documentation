package com.visa.vsb.compose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Time consuming action should not be here, we did it just for demo
        val languagesDataSource = LanguagesDataSource(this)

        window.statusBarColor = VISA_BLUE
        setContent {
            MaterialTheme(
                colorScheme = LightColorScheme
            ) {
                Route(languagesDataSource.pairList)
            }
        }
    }
}

@Composable
fun Route(languagesData: List<Pair<String, LanguagesDataSource.Language>>) {
    val navController = rememberNavController()
    val viewModel = viewModel<MainViewModel>()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(viewModel.currTheme, languagesData, onNavigateToThemeSelection = {
                navController.navigate("themeSelection")
            })
        }
        composable("themeSelection") {
            ThemeSelectionScreen(
                currThemeSelection = viewModel.currTheme,
                onBackButtonPress = {
                    navController.navigateUp()
                }, onThemeSelected = { theme ->
                    viewModel.currTheme = theme
                    navController.navigateUp()
                })
        }
    }
}
