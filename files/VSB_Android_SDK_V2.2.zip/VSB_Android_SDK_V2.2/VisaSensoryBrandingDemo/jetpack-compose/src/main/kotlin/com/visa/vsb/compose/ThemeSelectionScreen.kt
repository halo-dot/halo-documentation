package com.visa.vsb.compose

import android.util.Log
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.alpha

val re = Regex("[^A-Fa-f0-9]")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSelectionScreen(
    currThemeSelection: Theme,
    onBackButtonPress: () -> Unit,
    onThemeSelected: (color: Theme) -> Unit
) {
    var alertContent by rememberSaveable {
        mutableStateOf("")
    }
    var showAlertDialog by rememberSaveable {
        mutableStateOf(false)
    }
    var currThemeClass: Class<out Theme> by rememberSaveable(currThemeSelection) {
        mutableStateOf(currThemeSelection.javaClass)
    }
    var customColor by rememberSaveable(currThemeSelection) {
        mutableStateOf(
            if (currThemeSelection is CustomTheme) {
                currThemeSelection.hexColorCode.removePrefix("#")
            } else {
                "666666"
            }
        )
    }

    Column(
        Modifier
            .fillMaxHeight()
            .fillMaxWidth()
            .background(color = Color.White)
    ) {
        CenterAlignedTopAppBar(
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = Color(VISA_BLUE),
                titleContentColor = Color.White,
                actionIconContentColor = Color.White
            ),
            title = { Text("Branding Color Selection") },
            navigationIcon = {
                IconButton(onClick = onBackButtonPress) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            },
            actions = {
                TextButton(onClick = {
                    val customColorWithHashTag = "#$customColor"
                    val errorMsg = preCheck(currThemeClass, customColorWithHashTag)
                    if (errorMsg.isNotBlank()) {
//                        Toast.makeText(ctx, errorMsg, Toast.LENGTH_LONG).show()
                        alertContent = errorMsg
                        showAlertDialog = true
                        return@TextButton
                    }
                    onThemeSelected(
                        when (currThemeClass) {
                            DefaultWhiteTheme.javaClass -> {
                                DefaultWhiteTheme
                            }
                            DefaultBlueTheme.javaClass -> {
                                DefaultBlueTheme
                            }
                            CustomTheme::class.java -> {
                                CustomTheme(
                                    Color(android.graphics.Color.parseColor(customColorWithHashTag)),
                                    customColorWithHashTag
                                )
                            }
                            else -> throw Exception("Unknown theme.")
                        }
                    )
                }
                ) {
                    Text(
                        text = "OK",
                        color = Color.White,
                        fontSize = 16.sp
                    )
                }

            }
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp)
        ) {
            ThemeBlockSelectable(
                color = Color.White,
                title = DefaultWhiteTheme.title,
                desc = DefaultWhiteTheme.desc,
                selected = currThemeClass == DefaultWhiteTheme.javaClass
            ) {
                currThemeClass = DefaultWhiteTheme.javaClass
            }
            ThemeBlockSelectable(
                color = Color(VISA_BLUE),
                title = DefaultBlueTheme.title,
                desc = DefaultBlueTheme.desc,
                selected = currThemeClass == DefaultBlueTheme.javaClass
            ) {
                currThemeClass = DefaultBlueTheme.javaClass
            }
            CustomColorBlockSelectable(
                color = customColor,
                selected = currThemeClass == CustomTheme::class.java,
                onCustomColorChange = {
                    if (it.length > 6) {
                        return@CustomColorBlockSelectable
                    }
                    val answer = re.replace(it, "")
                    customColor = answer
                }
            ) {
                currThemeClass = CustomTheme::class.java
            }
        }

        if (showAlertDialog) {
            AlertDialog(
                onDismissRequest = { showAlertDialog = false },
                title = {
                    Text(text = "Alert")
                },
                text = {
                    Text(
                        text = alertContent,
                        fontSize = 16.sp
                    )
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showAlertDialog = false }) {
                        Text("OK")
                    }
                }
            )
        }
    }
}


@Composable
fun ThemeBlockSelectable(
    color: Color,
    title: String,
    desc: String,
    selected: Boolean,
    onThemeSelected: () -> Unit
) {
    ConstraintLayout(
        modifier = Modifier
            .height(96.dp)
            .fillMaxWidth()
            .clickable {
                onThemeSelected()
            }
    ) {
        val (colorBlockRuleRef, titleRuleRef, descRuleRef, tickRuleRef) = createRefs()
        Box(
            Modifier
                .padding(end = 16.dp)
                .size(56.dp)
                .background(color)
                .border(width = 1.dp, color = Color.Black)
                .constrainAs(colorBlockRuleRef) {
                    start.linkTo(parent.start)
                    centerVerticallyTo(parent)
                }
        )

        if (selected) {
            Text(text = "✓",
                fontSize = 16.sp,
                modifier = Modifier.constrainAs(tickRuleRef) {
                    end.linkTo(parent.end)
                    centerVerticallyTo(parent)
                })
        }

        Text(
            text = title,
            color = Color.Black,
            fontSize = 16.sp,
            modifier = Modifier
                .widthIn(min = 60.dp, max = 200.dp)
                .constrainAs(titleRuleRef) {
                    start.linkTo(colorBlockRuleRef.end)
                    top.linkTo(colorBlockRuleRef.top)
                }
        )
        Text(
            text = desc,
            color = Color.LightGray,
            fontSize = 12.sp,
            style = LocalTextStyle.current.merge(
                TextStyle(
                    lineHeight = 1.em,
                    platformStyle = PlatformTextStyle(
                        includeFontPadding = false
                    ),
                    lineHeightStyle = LineHeightStyle(
                        alignment = LineHeightStyle.Alignment.Center,
                        trim = LineHeightStyle.Trim.None
                    )
                )
            ),
            modifier = Modifier
                .widthIn(min = 60.dp, max = 200.dp)
                .padding(top = 4.dp)
                .constrainAs(descRuleRef) {
                    start.linkTo(colorBlockRuleRef.end)
                    top.linkTo(titleRuleRef.bottom)
                }
        )

    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun CustomColorBlockSelectable(
    color: String,
    selected: Boolean,
    onCustomColorChange: (String) -> Unit,
    onThemeSelected: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    ConstraintLayout(
        modifier = Modifier
            .height(96.dp)
            .fillMaxWidth()
            .clickable {
                onThemeSelected()
            }
    ) {
        val (colorBlockRuleRef,
            titleRuleRef,
            descRuleRef,
            tickRuleRef,
            hashTagRuleRef,
            textFieldRuleRef) = createRefs()
        Box(
            modifier = Modifier
                .padding(end = 16.dp)
                .size(56.dp)
                .run {
                    if (preCheck(CustomTheme::class.java, "#$color").isBlank()) {
                        Log.d("VisaSensoryBranding", "bg preCheck true")
                        background(Color(android.graphics.Color.parseColor("#$color")))
                    } else {
                        Log.d("VisaSensoryBranding", "bg preCheck false")
                        background(Color.White)
                    }
                }
                .border(width = 1.dp, color = Color.Black)
                .constrainAs(colorBlockRuleRef) {
                    start.linkTo(parent.start)
                    centerVerticallyTo(parent)
                }
        )

        if (selected) {
            Text(text = "✓",
                fontSize = 16.sp,
                modifier = Modifier.constrainAs(tickRuleRef) {
                    end.linkTo(parent.end)
                    centerVerticallyTo(parent)
                })
        }

        Text(
            text = CUSTOM_THEME_TITLE,
            color = Color.Black,
            fontSize = 16.sp,
            modifier = Modifier
                .widthIn(min = 60.dp, max = 200.dp)
                .constrainAs(titleRuleRef) {
                    start.linkTo(colorBlockRuleRef.end)
                    top.linkTo(colorBlockRuleRef.top)
                }
        )
        Text(
            text = CUSTOM_THEME_DESC,
            color = Color.LightGray,
            fontSize = 12.sp,
            style = LocalTextStyle.current.merge(
                TextStyle(
                    lineHeight = 1.em,
                    platformStyle = PlatformTextStyle(
                        includeFontPadding = false
                    ),
                    lineHeightStyle = LineHeightStyle(
                        alignment = LineHeightStyle.Alignment.Center,
                        trim = LineHeightStyle.Trim.None
                    )
                )
            ),
            modifier = Modifier
                .widthIn(min = 60.dp, max = 200.dp)
                .padding(top = 4.dp)
                .constrainAs(descRuleRef) {
                    start.linkTo(colorBlockRuleRef.end)
                    top.linkTo(titleRuleRef.bottom)
                }
        )

        Text(text = "#", modifier = Modifier
            .padding(top = 12.dp)
            .constrainAs(hashTagRuleRef) {
                start.linkTo(colorBlockRuleRef.end)
                top.linkTo(descRuleRef.bottom)
            })
        BasicTextField(
            value = color,
            onValueChange = onCustomColorChange,
            singleLine = true,
            textStyle = LocalTextStyle.current.copy(
                color = Color.Black, fontSize = 14.sp, textAlign = TextAlign.Start
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(
                onDone = { keyboardController?.hide() }),
            modifier = Modifier
                .height(32.dp)
                .width(96.dp)
                .padding(start = 4.dp, top = 8.dp)
                .constrainAs(textFieldRuleRef) {
                    start.linkTo(hashTagRuleRef.end)
                    bottom.linkTo(hashTagRuleRef.bottom)
                }
                .border(width = 1.dp, color = Color.Black))
    }
}

private fun preCheck(theme: Class<out Theme>, customColor: String): String {
    return if (theme == CustomTheme::class.java) {
        try {
            val color = android.graphics.Color.parseColor(customColor)
            val length = customColor.removePrefix("#").length
            if (color.alpha == 0) {
                return "Please enter a HEX color code without Alpha channel."
            }
            if (!(length == 3 || length == 6)) {
                return "Please enter a valid HEX color code."
            }

            if (!color.checkVisaColorContrast()) {
                return "Your custom color doesn't provide enough contrast." +
                        " Please enter another color."
            }
        } catch (e: Exception) {
            return "Please enter a valid HEX color code."
        }

        ""
    } else {
        ""
    }
}

internal fun Int.checkVisaColorContrast(): Boolean {
    val backdropColor = this
    val white = android.graphics.Color.WHITE
    val visaBlue = VISA_BLUE

    val whiteContrast = ColorUtils.calculateContrast(white, backdropColor)
    val blueContrast = ColorUtils.calculateContrast(visaBlue, backdropColor)

    return whiteContrast >= 3.0 || blueContrast >= 3.0
}


@Preview
@Composable
fun ThemeSelectionPreview() {
    MaterialTheme(
        colorScheme = LightColorScheme
    ) {
        ThemeSelectionScreen(DefaultBlueTheme, {}, {})
    }
}