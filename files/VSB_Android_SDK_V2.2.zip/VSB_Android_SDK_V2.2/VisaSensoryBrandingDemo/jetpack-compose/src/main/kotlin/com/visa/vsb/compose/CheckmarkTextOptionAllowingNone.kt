package com.visa.vsb.compose

import com.visa.CheckmarkTextOption

enum class CheckmarkTextOptionAllowingNone(val mapTo: CheckmarkTextOption?) {
    APPROVE(CheckmarkTextOption.APPROVE),
    SUCCESS(CheckmarkTextOption.SUCCESS),
    COMPLETE(CheckmarkTextOption.COMPLETE),
    NONE(null)
}
