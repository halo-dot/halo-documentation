package com.visa.vsb.compose

import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color


val VISA_BLUE: Int = android.graphics.Color.parseColor("#1434cb")
val VISA_YELLOW: Int = android.graphics.Color.parseColor("#fcc015")
val VISA_GREY: Int = android.graphics.Color.parseColor("#dedede")
val WHITE_IN_INT: Int = android.graphics.Color.parseColor("#FFFFFF")
val DIVIDER_LIGHT_GREY: Int = android.graphics.Color.parseColor("#eeeeee")



val LightColorScheme = lightColorScheme(
        primary = Color(VISA_BLUE),
        secondary = Color(VISA_YELLOW),
        tertiary = Color(VISA_GREY)
)
