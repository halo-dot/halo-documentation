package com.visa.vsb.compose

import androidx.compose.ui.graphics.Color


sealed interface Theme {
    val color: Color
    val title: String
    val desc: String
    val hexColorCode: String
}

object DefaultWhiteTheme : Theme {
    override val color: Color = Color.White
    override val hexColorCode: String = "#FFFFFF"
    override val title: String = "Default Light Theme"
    override val desc: String = "White background with full color elements"
}

object DefaultBlueTheme : Theme {
    override val color: Color = Color(VISA_BLUE)
    override val hexColorCode: String = "#1434CB"
    override val title: String = "Default Dark Theme"
    override val desc: String = "Visa Blue background with full color elements"
}

const val CUSTOM_THEME_TITLE_WITH_COLOR = "Custom - %s"
const val CUSTOM_THEME_TITLE: String = "Custom (fill in the color code below)"
const val CUSTOM_THEME_DESC: String = "With Visa monochrome elements"

open class CustomTheme(override val color: Color, override val hexColorCode: String) : Theme {
    override val title: String = CUSTOM_THEME_TITLE_WITH_COLOR
    override val desc: String = CUSTOM_THEME_DESC
}