package com.visa.vsb.compose

import androidx.lifecycle.ViewModel

class MainViewModel: ViewModel() {

    var currTheme: Theme = DefaultWhiteTheme

}