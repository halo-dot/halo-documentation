package com.visa.vsb.compose

import android.content.Context
import com.visa.R
import org.json.JSONObject
import java.util.*
import kotlin.collections.HashMap

class LanguagesDataSource(context: Context) {

    val pairList: LinkedList<Pair<String, Language>>

    init {
        val inputStream = context.resources.openRawResource(R.raw.languages)
        val languagesJsonString =
            inputStream.bufferedReader().use { it.readText() }  // defaults to UTF-8
        pairList = LinkedList()
        convertLanguagesJSONToObject(languagesJsonString).toSortedMap().forEach { entry ->
            pairList.add(Pair(entry.key, entry.value))
        }

    }

    private fun convertLanguagesJSONToObject(jsonString: String): Map<String, Language> {
        val rawObject = JSONObject(jsonString)
        val map = HashMap<String, Language>()
        rawObject.keys().forEach { key ->
            val perItemJsonObj = rawObject.getJSONObject(key)
            val name = perItemJsonObj.getString("name")
            val code = perItemJsonObj.getString("code")
            val fontFamily = perItemJsonObj.getString("fontFamily")
            val fontNames = perItemJsonObj.getString("fontNames")
            val dataObj = perItemJsonObj.getJSONObject("data")
            val approve = dataObj.getString("approve")
            val success = dataObj.getString("success")
            val complete = dataObj.getString("complete")
            val language = Language(
                name = name,
                code = code,
                fontFamily = fontFamily,
                fontNames = fontNames,
                data = TextOptionData(
                    approve = approve,
                    success = success,
                    complete = complete
                )
            )
            map[name] = language
        }
        return map
    }


    data class Language(
        val name: String,
        val code: String,
        val fontFamily: String,
        val fontNames: String, // Used in iOS only, to get the built-in font registered name.
        val data: TextOptionData
    )

    data class TextOptionData(
        val approve: String,
        val success: String,
        val complete: String
    )
}