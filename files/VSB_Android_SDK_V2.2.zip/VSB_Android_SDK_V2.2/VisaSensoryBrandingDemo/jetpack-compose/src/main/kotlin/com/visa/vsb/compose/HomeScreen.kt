package com.visa.vsb.compose

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.constraintlayout.compose.ConstraintLayout
import com.visa.CheckmarkMode
import com.visa.SensoryBrandingView


@Composable
fun HomeScreen(
    theme: Theme,
    languagesData: List<Pair<String, LanguagesDataSource.Language>>,
    onNavigateToThemeSelection: () -> Unit
) {
    var audioEnabled by rememberSaveable { mutableStateOf(false) }
    var hapticEnabled by rememberSaveable { mutableStateOf(false) }

    var checkmarkEnabled by rememberSaveable { mutableStateOf(false) }
    var checkmarkTextOption by rememberSaveable { mutableStateOf(CheckmarkTextOptionAllowingNone.NONE) }
    var checkmarkTextOptionMenuData by rememberSaveable {
        mutableStateOf(
            listOf(
                Pair("None", CheckmarkTextOptionAllowingNone.NONE),
                Pair("Approved", CheckmarkTextOptionAllowingNone.APPROVE),
                Pair("Success", CheckmarkTextOptionAllowingNone.SUCCESS),
                Pair("Completed", CheckmarkTextOptionAllowingNone.COMPLETE),
            )
        )
    }

    var checkmarkTextOptionDisplayName by rememberSaveable { mutableStateOf("None") }

    var constraintViewEnabled by rememberSaveable { mutableStateOf(false) }
    var constraintWidth by rememberSaveable { mutableStateOf("200") }

    var languageCode by rememberSaveable { mutableStateOf("en") }
    var languageDisplayName by rememberSaveable { mutableStateOf("English") }
    var languageMenuData by rememberSaveable { mutableStateOf(languagesData) }

    var showConstrainedSizeAlert by rememberSaveable { mutableStateOf(false) }

    var playingTheAnimation by rememberSaveable { mutableStateOf(false) }

    val ctx = LocalContext.current

    Core(
        theme = theme,
        languageCode = languageCode,
        audioEnabled = audioEnabled,
        hapticEnabled = hapticEnabled,
        checkmarkEnabled = checkmarkEnabled,
        constraintViewEnabled = constraintViewEnabled,
        checkmarkTextOption = checkmarkTextOption,
        checkmarkTextOptionDisplayName = checkmarkTextOptionDisplayName,
        constraintWidth = constraintWidth,
        languagesMenuData = languageMenuData,
        languagesDisplayName = languageDisplayName,
        checkmarkTextOptionMenuData = checkmarkTextOptionMenuData,
        showConstrainedSizeAlert = showConstrainedSizeAlert,
        onAudioSwitchChanged = {
            audioEnabled = it
        },
        onHapticSwitchChanged = {
            hapticEnabled = it
        },
        onCheckmarkSwitchChanged = {
            checkmarkEnabled = it
        },
        onConstraintViewSwitchChanged = {
            constraintViewEnabled = it
        },
        playingTheAnimation = playingTheAnimation,
        onAnimationEnd = {
            playingTheAnimation = false
            it?.message?.let { errorMsg ->
                Toast.makeText(ctx, errorMsg, Toast.LENGTH_SHORT).show()
            }
        },
        onPlayButtonClick = {
            // pre check for constrained view width
            if (constraintViewEnabled) {
                if (constraintWidth.isBlank()) {
                    showConstrainedSizeAlert = true
                    return@Core
                }
                try {
                    constraintWidth.toFloat() // If any issues happen due to the casting
                } catch (e: Exception) {
                    showConstrainedSizeAlert = true
                    return@Core
                }
            }
            playingTheAnimation = true
        },
        onConstraintWidthChanged = {
            constraintWidth = it.filter(Char::isDigit)
        },
        onLanguageMenuItemClick = {
            val languageItemData = it as LanguagesDataSource.Language
            languageCode = it.code
            languageDisplayName = it.name
            checkmarkTextOptionMenuData = listOf(
                Pair("None", CheckmarkTextOptionAllowingNone.NONE),
                Pair(languageItemData.data.approve, CheckmarkTextOptionAllowingNone.APPROVE),
                Pair(languageItemData.data.success, CheckmarkTextOptionAllowingNone.SUCCESS),
                Pair(languageItemData.data.complete, CheckmarkTextOptionAllowingNone.COMPLETE),
            )
            checkmarkTextOptionDisplayName = checkmarkTextOptionMenuData
                .find { pair -> pair.second == checkmarkTextOption }!!
                .first
        },
        onCheckmarkTextOptionMenuItemClick = { textOption ->
            checkmarkTextOption = textOption as CheckmarkTextOptionAllowingNone
            checkmarkTextOptionDisplayName = checkmarkTextOptionMenuData
                .find { pair -> pair.second == checkmarkTextOption }!!
                .first
        },
        onConstrainedSizeAlertDismiss = {
            showConstrainedSizeAlert = false
        },
        onNavigateToThemeSelection = onNavigateToThemeSelection
    )
}


@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun Core(
    theme: Theme,
    languageCode: String,
    audioEnabled: Boolean,
    hapticEnabled: Boolean,
    checkmarkEnabled: Boolean,
    constraintViewEnabled: Boolean,
    checkmarkTextOption: CheckmarkTextOptionAllowingNone,
    checkmarkTextOptionDisplayName: String,
    constraintWidth: String,
    languagesMenuData: List<Pair<String, Any>>,
    languagesDisplayName: String,
    checkmarkTextOptionMenuData: List<Pair<String, Any>>,
    showConstrainedSizeAlert: Boolean,
    onAudioSwitchChanged: (enabled: Boolean) -> Unit,
    onHapticSwitchChanged: (enabled: Boolean) -> Unit,
    onCheckmarkSwitchChanged: (enabled: Boolean) -> Unit,
    onConstraintViewSwitchChanged: (enabled: Boolean) -> Unit,
    onConstraintWidthChanged: (size: String) -> Unit,
    onLanguageMenuItemClick: (ref: Any) -> Unit,
    onCheckmarkTextOptionMenuItemClick: (ref: Any) -> Unit,
    playingTheAnimation: Boolean = false,
    onAnimationEnd: (error: Error?) -> Unit,
    onPlayButtonClick: () -> Unit,
    onConstrainedSizeAlertDismiss: () -> Unit,
    onNavigateToThemeSelection: () -> Unit,
) {
    Column(Modifier.background(Color.White)) {
        if (!playingTheAnimation) {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(VISA_BLUE),
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                title = { Text("Visa Sensory Branding") },
                actions = {
                    IconButton(onClick = { onPlayButtonClick() }) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = "Play the animation.",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            )
        }

        if (!playingTheAnimation) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 24.dp, end = 24.dp)
            ) {
                ThemeBlock(theme, onNavigateToThemeSelection)
                LightGreyDivider()

                DropdownMenuBlock(
                    title = "Language",
                    buttonTitle = languagesDisplayName,
                    menuData = languagesMenuData,
                    onDropdownItemClick = onLanguageMenuItemClick,
                )
                LightGreyDivider()

                SwitchBlock("Audio", audioEnabled, onAudioSwitchChanged)
                LightGreyDivider()

                SwitchBlock("Haptic", hapticEnabled, onHapticSwitchChanged)
                LightGreyDivider()

                SwitchBlock("Checkmark", checkmarkEnabled, onCheckmarkSwitchChanged)
                if (checkmarkEnabled) {
                    DropdownMenuBlock(
                        title = "Checkmark Text",
                        buttonTitle = checkmarkTextOptionDisplayName,
                        menuData = checkmarkTextOptionMenuData,
                        onDropdownItemClick = onCheckmarkTextOptionMenuItemClick
                    )
                }
                LightGreyDivider()

                SwitchBlock(
                    "Constrained View",
                    constraintViewEnabled,
                    onConstraintViewSwitchChanged
                )
                if (constraintViewEnabled) {
                    ConstraintSizeBlock(constraintWidth, onConstraintWidthChanged)
                }
                LightGreyDivider()
            }
        }

        if (playingTheAnimation) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .run {
                        if (!constraintViewEnabled) {
                            background(theme.color)
                        } else {
                            this
                        }
                    }

            ) {
                VisaSensoryBranding(
                    playingTheAnimation = playingTheAnimation,
                    onAnimationEnd = {
                        onAnimationEnd(it)
                    },
                    languageCode = languageCode,
                    backdropColor = android.graphics.Color.parseColor(theme.hexColorCode),
                    audioEnabled = audioEnabled,
                    hapticEnabled = hapticEnabled,
                    checkmarkEnabled = checkmarkEnabled,
                    constraintViewEnabled = constraintViewEnabled,
                    checkmarkTextOption = checkmarkTextOption,
                    constraintWidth = constraintWidth
                )
            }
        }

        if (showConstrainedSizeAlert) {
            AlertDialog(
                onDismissRequest = onConstrainedSizeAlertDismiss,
                title = {
                    Text(text = "Alert")
                },
                text = {
                    Text(
                        text = "Please type a valid width value.",
                        fontSize = 16.sp
                    )
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = onConstrainedSizeAlertDismiss) {
                        Text("OK")
                    }
                }
            )
        }
    }
}


@Composable
fun LightGreyDivider() {
    Divider(color = Color(DIVIDER_LIGHT_GREY))
}


@Composable
fun ThemeBlock(theme: Theme, onNavigateToThemeSelection: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .height(96.dp)
            .fillMaxWidth()
            .clickable {
                onNavigateToThemeSelection()
            }
    ) {
        Box(
            Modifier
                .size(56.dp)
                .background(theme.color)
                .border(width = 1.dp, color = Color.Black)
        )
        Column(Modifier.padding(start = 16.dp)) {
            Text(
                text = theme.title.format(theme.hexColorCode),
                color = Color.Black,
                fontSize = 16.sp
            )
            Text(
                text = theme.desc,
                color = Color.LightGray,
                fontSize = 12.sp
            )
        }
    }
}


@Composable
fun DropdownMenuBlock(
    title: String,
    buttonTitle: String,
    menuData: List<Pair<String, Any>>, // name & ref
    onDropdownItemClick: (ref: Any) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    ConstraintLayout(
        Modifier
            .height(96.dp)
            .fillMaxWidth()
    ) {
        val (titleRuleRef, actionRuleRef) = createRefs()
        Text(
            text = title,
            modifier = Modifier
                .constrainAs(titleRuleRef) {
                    start.linkTo(parent.start)
                    centerVerticallyTo(parent)
                }
        )
        Box(modifier = Modifier.constrainAs(actionRuleRef) {
            end.linkTo(parent.end)
            centerVerticallyTo(parent)
        }) {
            TextButton(
                onClick = { expanded = true }) {
                Text(text = buttonTitle)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                for ((name, ref) in menuData) {
                    DropdownMenuItem(text = { Text(name) }, onClick = {
                        expanded = false
                        onDropdownItemClick(ref)
                    })
                }
            }
        }
    }
}


@Composable
fun SwitchBlock(
    title: String,
    enable: Boolean,
    switchAction: (enabled: Boolean) -> Unit
) {
    ConstraintLayout(
        Modifier
            .height(96.dp)
            .fillMaxWidth()
    ) {
        val (titleRuleRef, actionRuleRef) = createRefs()
        Text(
            text = title, modifier = Modifier
                .constrainAs(titleRuleRef) {
                    start.linkTo(parent.start)
                    centerVerticallyTo(parent)
                }
        )
        Switch(
            checked = enable,
            onCheckedChange = switchAction,
            modifier = Modifier.constrainAs(actionRuleRef) {
                end.linkTo(parent.end)
                centerVerticallyTo(parent)
            })
    }
}


@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun ConstraintSizeBlock(
    widthValue: String,
    onWidthValueChange: (newValue: String) -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    ConstraintLayout(
        Modifier
            .height(96.dp)
            .fillMaxWidth()
    ) {
        val (titleRuleRef, actionRuleRef) = createRefs()
        Text(
            text = "Constrained Width (dp)",
            modifier = Modifier
                .constrainAs(titleRuleRef) {
                    start.linkTo(parent.start)
                    centerVerticallyTo(parent)
                }
        )
        BasicTextField(
            value = widthValue,
            onValueChange = onWidthValueChange,
            singleLine = true,
            textStyle = LocalTextStyle.current.copy(
                color = Color.Black, fontSize = 14.sp, textAlign = TextAlign.End
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { keyboardController?.hide() }),
            modifier = Modifier
                .height(32.dp)
                .width(96.dp)
                .padding(top = 6.dp)
                .constrainAs(actionRuleRef) {
                    end.linkTo(parent.end)
                    centerVerticallyTo(parent)
                }
                .border(width = 1.dp, color = Color.Black))
    }
}

@Composable
fun VisaSensoryBranding(
    modifier: Modifier = Modifier,
    languageCode: String,
    backdropColor: Int,
    audioEnabled: Boolean,
    hapticEnabled: Boolean,
    checkmarkEnabled: Boolean,
    constraintViewEnabled: Boolean,
    checkmarkTextOption: CheckmarkTextOptionAllowingNone,
    constraintWidth: String,
    playingTheAnimation: Boolean = false,
    onAnimationEnd: (error: Error?) -> Unit
) {
    if (playingTheAnimation) {
        val width = if (constraintViewEnabled) constraintWidth.toFloat() else Float.MAX_VALUE
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(),
            contentAlignment = Alignment.Center,
        ) {
            AndroidView(
                modifier = modifier
                    .width(Dp(width))
                    .wrapContentHeight()
                    .run {
                        if (constraintViewEnabled) {
                            border(
                                width = 1.dp,
                                color = Color.Black
                            )
                        } else {
                            this
                        }
                    },
                factory = { ctx ->
                    val vsb = SensoryBrandingView(ctx, null)
                    // vsb.languageCode = "en"
                    vsb
                },
                update = { view ->
                    if (playingTheAnimation) {
                        view.languageCode = languageCode
                        view.backdropColor = backdropColor
                        view.soundEnabled = audioEnabled
                        view.hapticEnabled = hapticEnabled
                        view.checkmarkMode = if (checkmarkEnabled) {
                            if (checkmarkTextOption == CheckmarkTextOptionAllowingNone.NONE) {
                                CheckmarkMode.CHECKMARK
                            } else {
                                CheckmarkMode.CHECKMARK_WITH_TEXT
                            }
                        } else {
                            CheckmarkMode.NONE
                        }
                        if (checkmarkEnabled
                            && checkmarkTextOption != CheckmarkTextOptionAllowingNone.NONE
                        ) {
                            view.checkmarkText = checkmarkTextOption.mapTo!!
                        }

                        view.animate {
                            onAnimationEnd(it)
                        }
                    }
                })
        }
    }
}


@Preview
@Composable
fun ComposablePreview() {
    var audioEnabled by remember { mutableStateOf(false) }
    var hapticEnabled by remember { mutableStateOf(false) }
    var checkmarkEnabled by remember { mutableStateOf(true) }
    val checkmarkTextOption by remember { mutableStateOf(CheckmarkTextOptionAllowingNone.NONE) }
    var constraintViewEnabled by remember { mutableStateOf(true) }
    var playingTheAnimation by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = LightColorScheme
    ) {
        Core(
            theme = DefaultWhiteTheme,
            languageCode = "en",
            audioEnabled = audioEnabled,
            hapticEnabled = hapticEnabled,
            checkmarkEnabled = checkmarkEnabled,
            constraintViewEnabled = constraintViewEnabled,
            checkmarkTextOption = checkmarkTextOption,
            constraintWidth = "200",
            languagesDisplayName = "English",
            checkmarkTextOptionDisplayName = "None",
            languagesMenuData = listOf(),
            checkmarkTextOptionMenuData = listOf(),
            showConstrainedSizeAlert = false,
            onAudioSwitchChanged = {
                audioEnabled = it
            },
            onHapticSwitchChanged = {
                hapticEnabled = it
            },
            onCheckmarkSwitchChanged = {
                checkmarkEnabled = it
            },
            onConstraintViewSwitchChanged = {
                constraintViewEnabled = it
            },
            playingTheAnimation = playingTheAnimation,
            onAnimationEnd = {
                playingTheAnimation = false
            },
            onPlayButtonClick = {},
            onConstraintWidthChanged = {},
            onLanguageMenuItemClick = {},
            onCheckmarkTextOptionMenuItemClick = {},
            onConstrainedSizeAlertDismiss = {},
            onNavigateToThemeSelection = {}
        )
    }
}
