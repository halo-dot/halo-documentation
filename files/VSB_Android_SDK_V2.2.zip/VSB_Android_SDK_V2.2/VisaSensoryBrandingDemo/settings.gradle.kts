pluginManagement {
    val versions = file("deps.versions.toml").readText()
    val regexPlaceHolder = "%s\\s\\=\\s\\\"([A-Za-z0-9\\.\\-]+)\\\""
    val getVersion =
        { s: String -> regexPlaceHolder.format(s).toRegex().find(versions)!!.groupValues[1] }

    plugins {
        id("com.android.application") version getVersion("agpVer") apply false
        id("com.android.library") version getVersion("agpVer") apply false
        kotlin("android") version getVersion("kotlinVer") apply false
    }

    repositories {
        mavenCentral()
        google()
        gradlePluginPortal()
        mavenLocal()
    }

}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        mavenLocal()
    }
    versionCatalogs {
        create("deps") {
            from(files("./deps.versions.toml"))
        }
    }
}

// 4 Demos
include("android-view-kt", "android-view-java", "jetpack-compose", "containers")

// Sensory Branding SDK
include(":visa-sensory-branding-sdk")
val sdkProj = project(":visa-sensory-branding-sdk")
sdkProj.projectDir = file("../visa-sensory-branding-sdk")


/////////////////////////////////////////// For Visa internal testing only
/**
 * This extension is for Visa developer to attach external source module to current repo.
 * The SDK integration does not require it.
 */
fun isVisaSensoryBrandingSourceModeEnabled(): Boolean {
    val localPropFile = File("local.properties")
    if (localPropFile.exists().not()) {
        return false
    }
    val prop = java.util.Properties()
    prop.load(localPropFile.inputStream())
    val sourceMode = prop.getProperty("visa.sensorybranding.source")
    return (sourceMode != null && sourceMode.toBoolean())
}
if (isVisaSensoryBrandingSourceModeEnabled()) {
    includeBuild("../VisaSensoryBranding") {
        dependencySubstitution {
            substitute(module("com.visa:sensorybranding"))
                .using(project(":visa-sensory-branding"))
        }
    }
}