import org.gradle.api.Project
import java.io.File
import java.util.*

/**
 * This extension is for Visa developer to attach external source module to current repo.
 * The SDK integration does not require it, please ignore.
 */
fun Project.isVisaSensoryBrandingSourceModeEnabled(): Boolean {
    val localPropFile = File("local.properties")
    if (localPropFile.exists().not()) {
        return false
    }
    val prop = Properties()
    prop.load(localPropFile.inputStream())
    val sourceMode = prop.getProperty("visa.sensorybranding.source")
    return (sourceMode != null && sourceMode.toBoolean())
}

/**
 * This extension is for Visa developer to attach external source module to current repo.
 * The SDK integration does not require it， please ignore.
 */
fun Project.usingVisaSensoryBrandingSourceOrApply(block: () -> Unit) {
    if (isVisaSensoryBrandingSourceModeEnabled()) {
        // This is a dummy coordination that will be replaced
        // by VisaSensoryBranding source code module through composite-build.
        dependencies.add("implementation", "com.visa:sensorybranding:+")
    } else {
        block.invoke()
    }
}
