//pluginManagement {
//
//    plugins {
//        id("org.gradle.kotlin.kotlin-dsl") version "2.3.3" apply false
//    }
//
//    resolutionStrategy {
//        eachPlugin {
//            if (requested.id.id == "org.gradle.kotlin.kotlin-dsl") {
//                useModule("org.gradle.kotlin:gradle-kotlin-dsl-plugins:2.3.3")
//            }
//        }
//    }
//
//}
