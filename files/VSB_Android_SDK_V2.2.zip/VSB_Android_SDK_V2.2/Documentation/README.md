#Visa Sensory Branding - Android SDK Integration

## Prerequisite

Download the latest Android SDK zip file, including the Demo App project and SDK module.

The SDK requires:

1. Android 5.0 or above.
2. Gradle 5 or above.
3. Android Gradle Plugin 4 or above.
4. `androidx.appcompat:appcompat:1.2.0` or above (the Android Support library is no longer supported).
5. Java 8 or above, Kotlin 1.6 or above.

To run the demo app, it requires: 

1. Android Studio 2022.3.1 or above.
2. Gradle 8.2 or above.
2. Android Gradle Plugin 8.1.0 or above.


## Demo App

1. Please open `${sdkFolder}/VisaSensoryBrandingDemo` project by Android Studio, wait a while for the Gradle Sync.
2. Make sure you connected the emulators or physical devices to the computer, then run the main demo application by typing the command `./gradlew :jetpack-compose:installDebug`.
3. Select the options to test for in the main screen, and press the play button at the top right to see the logo animation.


![](./media/android-sdk-demo-app-installation.png)
<img src="media/android-sdk-demo-app-screen.png" width="180"/>



## Integration

### Import the SDK module

1\. Copy the `${sdkFolder}/visa-sensory-branding-sdk` module to your project, it's a pre-configured Gradle module for `visa-sensory-branding-${sdkVersion}.aar`.

2\. Add the SDK module to your own modules' `build.gradle(.kts)` by below code:

``` Kotlin
dependencies {
    ...
	implementation(project(":visa-sensory-branding-sdk"))
}
```

3\. Click `Gradle Sync` button of Android Studio to load the SDK.


4\. You can find the integration examples under below folders inside the package.

<img src="media/android-sdk-samples.png" width="360"/> 


### Initialization

Import the Visa Sensory Branding class reference into any source files as necessary.

Java/Kotlin:

``` Kotlin
import com.visa.SensoryBrandingView
```


XML Layout:

``` xml
<com.visa.SensoryBrandingView
    android:id="@+id/vsb"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_centerInParent="true"/>
```

Java + View:

``` Java
SensoryBrandingView vsb = (SensoryBrandingView) findViewById(R.id.vsb);
```


Kotlin + View:

``` Kotlin
val vsb = findViewById<SensoryBrandingView>(R.id.vsb)
```


Kotlin + Jetpack Compose:

``` Kotlin
// Wrap the SensoryBrandingView with AndroidView
AndroidView(
    modifier = Modifier
        .width(Dp(width))
        .wrapContentHeight(),
	factory = { ctx ->
        val vsb = SensoryBrandingView(ctx, null)
        // More configurations...
        // vsb.languageCode = "en"
        vsb
    },
    update = { vsb ->  })
```



### Animate

Activates the Visa Sensory Branding animation.

Java + View:

``` Java
vsb.animate(error -> {
    Log.d("SensoryBrandingView", error == null ? "OK" : error.getMessage());
    return null;
});
```

Kotlin + View:

``` Kotlin
vsb.animate { error ->
    Log.d("SensoryBrandingView", error?.message ?: "OK")
}
```

Kotlin + Jetpack Compose:

``` Kotlin
// We need a property to trigger animation
var playingTheAnimation by rememberSaveable { mutableStateOf(false) }

// Wrap the SensoryBrandingView with AndroidView
AndroidView(
    modifier = Modifier
        .width(Dp(width))
        .wrapContentHeight(),
    factory = { ctx ->
        val vsb = SensoryBrandingView(ctx, null)
        // More configurations...
        // vsb.languageCode = "en"
        vsb
    },
    update = { vsb ->
	    if (playingTheAnimation) {	        
	        vsb.animate { result ->
	            Log.d("SensoryBrandingView", result?.message ?: "OK")
	        }
	    }
	 })
```

3 possible error messages (Error#getMessage()): 

|Error Message|Note|
|:--:|:--:|
|"Previous animation still in progress, cannot start a new animation."|Please wait for a while till animation displays. |
|"Invalid background color selected, contrast levels are below 3:1 against #FFFFFF and #1434CB."|Please choose different background color. |
|"Alpha channel is not supported for backdrop color."|Please choose different background color.  |

### Sizing and layout  

You can choose to have the Visa animation render in full screen on a device, or in a constrained view in context of other UI elements. To render in full screen, simply initialize the container to fit device height and width and set background color to same as backdropColor. For constrained view, specify the width of SensoryBrandingView during initialization. 

The width of the animation object will not be larger than 60% of the screen's width. If the width is set to be larger, it will be resized to be 60% of the screen's width. 

The width of the animation object will not be smaller than 20% of the screen's width. If the width is set to be smaller, it will be resized to be 20% of the screen's width. 


## Animation Configuration Parameters

### Language Code

Define the language of the texts present below the checkmark.

Java:

``` Java
vsb.setLanguageCode("en");
```

Kotlin:

``` Kotlin
vsb.languageCode = "en"
```

Please refer to “Available language codes for integration” table under Appendix section. 

### Backdrop Color

The color behind the animation, used to determine the Visa logo colors. Specify Visa Blue(`#1434CB`) for a white Visa logo. Specify White(`#FFFFFF`) for a blue Visa logo. Any other color will result in either blue or white color applied to the Logo, depending on contrast.

**Note:** Do not set `backdropColor` with simi-transparent color or make it transparent.

Java:

``` Java
vsb.setBackdropColor(Color.parseColor("#123333"));
```

Kotlin:

``` Kotlin
vsb.backdropColor = Color.parseColor("#123333")
```

### Sound

Set to true to enable sound. (true by default)

Java:

``` Java
vsb.setSoundEnabled(true);
```

Kotlin:

``` Kotlin
vsb.soundEnabled = true
```

### Haptic Feedback

Set to true to enable haptic feedback. (true by default)


Java:

``` Java
vsb.setHapticEnabled(true);
```

Kotlin:

``` Kotlin
vsb.hapticEnabled = true
```


### Checkmark

This parameter enables/disables checkmark screen after visa logo animation: 
 
Checkmark Mode includes: 

- `CheckmarkMode.CHECKMARK`: shows checkmark at the end of the animation without text (default)
- `CheckmarkMode.CHECKMARK_WITH_TEXT`: shows checkmark and checkmark text at the end of the animation 
- `CheckmarkMode.NONE`: no checkmark at the end of the animation 


Checkmark Text includes:

- `CheckmarkTextOption.APPROVE` (default)
- `CheckmarkTextOption.SUCCESS`
- `CheckmarkTextOption.COMPLETE`


Java:

``` Java
vsb.setCheckmarkMode(CheckmarkMode.CHECKMARK_WITH_TEXT);
vsb.setCheckmarkText(CheckmarkTextOption.APPROVE);
```

Kotlin:

``` Kotlin
vsb.checkmarkMode = CheckmarkMode.CHECKMARK_WITH_TEXT
vsb.checkmarkText = CheckmarkTextOption.APPROVE
```


## Migration Steps for Existing Users

1. Replace existing SDK, refer to Requirements above.
2. Migrate existing configurations in the table below.

|Option|Original|New changes|
|:--:|:--:|:--:|
|Constrained Flags|`setConstrainedFlags(Boolean) `|Obsolesced|
|Haptic Feedback|`setHapticFeedbackEnabled(Boolean)`|`setHapticEnabled(Boolean)`|
|Checkmark Options|`setCheckMarkShown(Boolean)`|`setCheckmarkMode(CheckmarkMode.XXX)`<br>`setCheckmarkText(CheckmarkTextOption.XXX)`
|Language Code| N/A | `setLanguageCode("xx")` |


## React Native

React Native serves as a bridge to construct native views, grounded in React's declarative UI framework, thereby enabling integration with Visa Sensory Branding's native SDKs for both iOS and Android platforms.

Currently, there are two methodologies available to encapsulate native views for embedding into a React Native application:

- Native Components: refer to the official documentation https://reactnative.dev/docs/native-components-android
- Fabric Native Components: refer to the official documentation https://reactnative.dev/docs/the-new-architecture/pillars-fabric-components

Developers are advised to select a method that aligns with their React Native version and the status of their ongoing project.


## Flutter

Flutter's "Platform Views" allow you to embed native views in a Flutter app, it supports two modes: **hybrid composition** and **virtual displays**:

- Hybrid composition appends the native `android.view.View` to the view hierarchy. Therefore, keyboard handling, and accessibility work out of the box.
- Virtual displays render the `android.view.View instance` to a texture, so it's not embedded within the Android Activity's view hierarchy. Certain platform interactions such as keyboard handling and accessibility features might not work.

The Visa Sensory Branding SDK is compliant with accessibility standards. For optimal accessibility support, we suggest using the hybrid composition method. Consult the official documentation below for a detailed guide on how to integrate the Android native view: https://docs.flutter.dev/platform-integration/android/platform-views


## Appendix

### Available language codes for integration

Please refer to this [link](https://support.google.com/accessibility/android/answer/11101402?hl=en) for languages supported by Talkback service.

|Language Name|Language Code|
|:--:|:--:|
| English | en | Y |
| Arabic| ar | Y |
| Azeri | az |
| Bahasa Indonesia | id |
| Bosnian | bs |
| Bulgarian | bg |
| Canadian English | en_ca |  Y |
| Canadian French | fr_ca | Y |
| Croatian | hr |
| Czech | cs | Y |
| Danish | da | Y |
| Dutch | nl | Y |
| Finnish | fi | Y |
| French | fr | Y |
| Georgian | ka |
| German | de | Y |
| Greek | el | Y |
| Hebrew | he | Y |
| Hungarian | hu | Y |
| Icelandic | is |
| Italian | it | Y |
| Latvian | lv |
| Lithuanian | lt |
| Japanese | ja | Y |
| Kazakh | kk |
| Khmer | km |
| Kinyarwanda | rw |
| Korean | ko | Y |
| Mongolian | mn |
| Norwegian | no | Y |
| Polish | pl | Y |
| Portuguese (Brazilian) | pt_br | Y |
| Portuguese (Regular) | pt | Y |
| Romanian | ro | Y |
| Russian | ru | Y |
| Serbian | sr |
| Simplified Chinese | zh_cn | Y |
| Slovakian | sk | Y |
| Slovenian | sl |
| Spanish (AR) | es_ar |
| Spanish (MX) | es_mx | Y |
| Spanish (LA) | es_la|
| Spanish (ES) | es | Y |
| Swedish | sv | Y |
| Thai | th | Y |
| Traditional Chinese (HK) | zh_hk | Y |
| Traditional Chinese (TW) | zh_tw | Y |
| Turkish | tr | Y |
| UK English | en_gb | Y |
| Ukrainian | ua |
| Vietnamese | vi |
