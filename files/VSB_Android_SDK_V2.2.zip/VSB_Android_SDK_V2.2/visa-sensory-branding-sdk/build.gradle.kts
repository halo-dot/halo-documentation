val versions = file("../VisaSensoryBrandingDemo/deps.versions.toml").readText()
val regexPlaceHolder = "%s\\s\\=\\s\\\"([A-Za-z0-9\\.\\-]+)\\\""
val getVersion =
    { s: String -> regexPlaceHolder.format(s).toRegex().find(versions)!!.groupValues[1] }

configurations.maybeCreate("default")
// Please change to a fixed version when integrating to your project
artifacts.add("default", file("visa-sensory-branding-${getVersion("sdkVer")}.aar"))